# SON_ZAD2

---

## 📝 Changelog

### Changes in Version 1.1.2

#### ✨ New Features
-  Nothing.

## 🚀 Installation

To install the latest version, run:
```bash
pip install SON_ZAD2-tests
```
![IMG_6691](https://paczaizm.pl/content/wp-content/uploads/to-sie-zateguje-typowy-polak-nosacz-malpa-robotnik-budowlaniec-wykonczeniowiec.jpg)


