# SON_ZAD2
![IMG_6691](https://paczaizm.pl/content/wp-content/uploads/to-sie-zateguje-typowy-polak-nosacz-malpa-robotnik-budowlaniec-wykonczeniowiec.jpg)
